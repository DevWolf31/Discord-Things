const Base64 = {};
const input = prompt;
const output = alert;
const encodeJson = JSON.stringify;
const decodeJson = JSON.parse;
const encodeUri = encodeURIComponent;
const decodeUri = decodeURIComponent;
const getById = (id) => document.getElementById(id);

Base64.encode = (object, code) =>
{
    if(typeof object === "object")
    {
        var v0 = {data: object, code: code};
        var v1 = encodeJson(v0);
        var v2 = btoa(unescape(encodeUri(v1)));
        
        return v2;
    }
    else
    {
        console.error("Invalid {object} type!");
    }
};

Base64.decode = (string, code) =>
{
    if(typeof string === "string")
    {
        var v0 = decodeUri(escape(atob(string)));
        var v1 = decodeJson(v0);
        var v2 = v1.data, v3 = v1.code;
        
        if(v3 == code)
        {
            return v2;
        }
        else
        {
            console.error("Invalid {code} value!");
        }
    }
    else
    {
        console.error("Invalid {string} type");
    }
};

var option_value = 1;
var data_value = "Texto";
var code_value = "Cla";

getById("option").onchange = () =>
{
    option_value = getById("option").value;
    
    if(option_value == "1")
    {
        getById("action").innerHTML = "Cifrar";
    }
    else if(option_value == "2")
    {
        getById("action").innerHTML = "Descifrar";
    }
};

getById("data").onchange = () =>
{
    data_value = getById("data").value;
};

getById("code").onchange = () =>
{
    code_value = getById("code").value;
};

getById("action").onclick = () =>
{
    if(option_value == "1")
    {
        console.log("Encoding ...");
        getById("result").value = Base64.encode({data: data_value}, code_value);
    }
    else if(option_value == "2")
    {
        console.log("Decoding ...");
        getById("result").value = Base64.decode(data_value, code_value).data;
    }
};